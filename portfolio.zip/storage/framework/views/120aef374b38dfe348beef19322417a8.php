<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description', 'Laravel developer portfolio: web apps, APIs, admin panels, ecommerce.'); ?>">

    <!-- FAVICONS -->
    <link rel="icon" type="image/png" href="<?php echo e(asset('images/favicon-192x192.png')); ?>">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>
</head>

<body class="min-h-screen text-slate-100">
    <div class="site-bg relative">

        <!-- GRID OVERLAY -->
        <div class="absolute inset-0 cyber-grid opacity-60 pointer-events-none"></div>

        <?php echo $__env->make('partials.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <main class="pt-16 relative z-10">
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/layouts/website.blade.php ENDPATH**/ ?>