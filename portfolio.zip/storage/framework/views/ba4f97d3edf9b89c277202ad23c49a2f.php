<?php $__env->startSection('title', 'Bappa Sutradhar | Home'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-fade">

        <!-- HERO -->
        <section class="mx-auto max-w-6xl px-4 py-10">
            <div class="grid md:grid-cols-[7fr_3fr] gap-10 items-start">

                <!-- LEFT HERO CARD -->
                <div class="relative rounded-md p-7 glass cyber-glow scanline">

                    <p class="text-emerald-200/90 text-sm tracking-widest cyber-text">
                        CUSTOM WEB SERVICE PORTALS
                    </p>

                    <h1 class="mt-3 text-3xl md:text-5xl font-extrabold text-white leading-tight">
                        Laravel Developer — Build Fast, Secure Web Apps
                    </h1>

                    <p class="mt-4 text-base text-white/70 max-w-3xl">
                        I build scalable Laravel web apps, APIs, admin panels, ERP solutions, news portals,
                        ecommerce platforms, business websites, and custom management systems.
                        I also work with WordPress customization and theme development.
                    </p>

                    <div class="mt-6 flex flex-wrap gap-3">
                        <a href="<?php echo e(route('contact')); ?>"
                            class="rounded-md bg-emerald-400/20 border border-emerald-400/30 px-6 py-3 font-semibold text-emerald-100 hover:bg-emerald-400/30 transition">
                            Hire Me
                        </a>

                        <a href="<?php echo e(route('projects')); ?>"
                            class="rounded-md border border-white/10 bg-white/5 px-6 py-3 font-semibold text-white hover:border-emerald-400/30 transition">
                            View Projects
                        </a>

                        <a href="<?php echo e(route('contact')); ?>"
                            class="rounded-md border border-white/10 bg-white/5 px-6 py-3 font-semibold text-white hover:border-emerald-400/30 transition">
                            Get a Free Quote
                        </a>
                    </div>

                    <!-- ACTIVATE PORTAL -->
                    <div class="mt-6 flex items-center gap-4">
                        <div class="relative h-20 w-20 grid place-items-center">
                            <div class="absolute inset-0 rounded-full border border-emerald-400/30 animate-ping"></div>
                            <div class="absolute inset-3 rounded-full border border-emerald-400/25"></div>
                            <div class="absolute inset-6 rounded-full border border-emerald-400/20"></div>

                            <!-- ACTUALLY SMALLER NEON ICON -->
                            <span class="text-emerald-300 text-sm font-bold scale-[0.85] translate-x-[1px] drop-shadow-[0_0_3px_rgba(52,211,153,0.7)] drop-shadow-[0_0_8px_rgba(52,211,153,0.4)] animate-pulse">
                                ▶︎
                            </span>
                        </div>

                        <div>
                            <p class="text-white font-semibold">Activate Portal</p>
                            <p class="text-xs text-white/55">Available for freelance • 24h response</p>
                        </div>
                    </div>

                    <div class="mt-6 flex flex-wrap gap-2 text-sm">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = ['3+ Years', 'Laravel', 'CodeIgniter', 'PHP', 'MySQL', 'REST API', 'WordPress', 'SQA']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span
                                class="rounded-full border border-emerald-400/15 bg-emerald-400/5 px-3 py-1 text-emerald-100/90">
                                <?php echo e($t); ?>

                            </span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>

                <!-- RIGHT PROFILE CARD -->
                <div class="rounded-md p-5 glass-soft cyber-glow">
                    <div class="flex justify-center">
                        <div class="relative w-full max-h-[380px] md:max-h-[260px] overflow-hidden rounded-md border border-emerald-400/15">

                            <img src="<?php echo e(asset('images/profile.jpg')); ?>" alt="Bappa Sutradhar"
                                class="w-full max-h-[380px] md:max-h-[260px] object-cover" />

                            <!-- DARK OVERLAY -->
                            <div class="absolute inset-0 bg-black/30"></div>

                            <!-- CYBER NOISE (VISIBLE) -->
                            <div class="absolute inset-0 cyber-noise pointer-events-none opacity-50"></div>

                            <!-- SCANLINE -->
                            <div class="absolute inset-0 scanline opacity-40 pointer-events-none"></div>

                            <!-- Glow corner accents -->
                            <div class="absolute top-2 left-2 h-5 w-5 border-t-2 border-l-2 border-emerald-400/60"></div>
                            <div class="absolute top-2 right-2 h-5 w-5 border-t-2 border-r-2 border-emerald-400/60"></div>
                            <div class="absolute bottom-2 left-2 h-5 w-5 border-b-2 border-l-2 border-emerald-400/60"></div>
                            <div class="absolute bottom-2 right-2 h-5 w-5 border-b-2 border-r-2 border-emerald-400/60">
                            </div>
                        </div>
                    </div>


                    <div class="mt-4 flex items-center justify-between">
                        <div>
                            <p class="text-xs text-white/55">Status</p>
                            <p class="text-lg font-bold text-white">Freelance</p>
                        </div>
                        <span
                            class="text-xs rounded-full bg-emerald-400/15 border border-emerald-400/25 px-3 py-1 text-emerald-200">
                            Open
                        </span>
                    </div>

                    <div class="mt-4 grid grid-cols-3 gap-2 text-center">
                        <div class="rounded-md border border-white/10 bg-white/5 p-3">
                            <p class="text-sm font-bold text-white">20+</p>
                            <p class="text-[11px] text-white/55">Projects</p>
                        </div>
                        <div class="rounded-md border border-white/10 bg-white/5 p-3">
                            <p class="text-sm font-bold text-white">Fast</p>
                            <p class="text-[11px] text-white/55">Delivery</p>
                        </div>
                        <div class="rounded-md border border-white/10 bg-white/5 p-3">
                            <p class="text-sm font-bold text-white">Clean</p>
                            <p class="text-[11px] text-white/55">Code</p>
                        </div>
                    </div>

                    <a href="<?php echo e(route('contact')); ?>"
                        class="mt-4 block text-center rounded-md bg-white text-slate-950 font-semibold px-4 py-3 hover:bg-white/90">
                        Let’s Talk
                    </a>
                </div>

            </div>
        </section>


        <!-- SERVICES -->
        <section class="mx-auto max-w-6xl px-4 py-12">
            <div class="mb-8">
                <h2 class="text-2xl md:text-3xl font-bold text-white">Services</h2>
                <p class="mt-2 text-white/70 max-w-2xl">
                    I provide complete web development and quality assurance services,
                    focused on scalable architecture, clean code, and reliable delivery.
                </p>
            </div>

            <div class="grid md:grid-cols-3 gap-6">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = [
                        ['🧩', 'Laravel Web Applications', 'Custom Laravel web applications including ecommerce platforms, admin panels, dashboards, authentication, roles & permissions, and scalable backend systems.'],
                        ['🏢', 'ERP & Management Systems', 'ERP solutions, inventory management, HR, accounting modules, and custom business management systems tailored to your workflow.'],
                        ['🔗', 'REST API Development', 'Secure REST APIs for mobile apps, third-party integrations, authentication systems, and scalable backend services.'],
                        ['📰', 'CMS & News Portals', 'News portals and CMS platforms with role-based editors, SEO-friendly URLs, media management, and publishing workflows.'],
                        ['🎨', 'WordPress Customization', 'WordPress theme development & customization, performance optimization, plugin integration, and business website development.'],
                        ['✅', 'Software Quality Assurance (SQA)', 'Manual testing, functional and regression testing, bug reporting, and quality checks to ensure stable, secure, and reliable applications.'],
                    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $srv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="rounded-md p-6 glass-soft cyber-glow hover:border-emerald-400/25 transition">
                        <div class="text-3xl mb-3"><?php echo e($srv[0]); ?></div>
                        <h3 class="font-semibold text-lg text-white"><?php echo e($srv[1]); ?></h3>
                        <p class="mt-2 text-white/70 text-sm"><?php echo e($srv[2]); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            <div class="mt-10 text-center">
                <a href="<?php echo e(route('contact')); ?>"
                    class="inline-block rounded-md bg-emerald-400/20 border border-emerald-400/30 px-6 py-3 font-semibold text-emerald-100 hover:bg-emerald-400/25 transition cyber-glow">
                    Discuss Your Project
                </a>
            </div>
        </section>


        <!-- FEATURED PROJECTS -->
        <section class="mx-auto max-w-6xl px-4 pb-16">
            <div class="flex items-end justify-between gap-4">
                <h2 class="text-2xl font-bold text-white">Featured Projects</h2>
                <a href="<?php echo e(route('projects')); ?>" class="text-sm font-semibold text-emerald-200 hover:text-emerald-100">
                    See all →
                </a>
            </div>

            <div class="mt-6 grid md:grid-cols-3 gap-5">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('projects.show', $p['slug'])); ?>"
                        class="group block rounded-md overflow-hidden glass-soft cyber-glow hover:border-emerald-400/25 transition">

                        <!-- IMAGE -->
                        <div class="relative h-60 px-6 pt-6 overflow-hidden">
                            <img src="<?php echo e(asset('images/projects/' . $p['image'])); ?>" alt="<?php echo e($p['title']); ?>"
                                class="h-full w-full object-cover" loading="lazy" decoding="async">

                            <!-- Overlay -->
                            <div class="absolute inset-0 bg-black/30"></div>

                            <!-- Cyber accents -->
                            <div class="absolute inset-0 scanline opacity-40 pointer-events-none"></div>
                        </div>

                        <!-- CONTENT -->
                        <div class="p-6">
                            <h3 class="font-semibold text-white"><?php echo e($p['title']); ?></h3>
                            <p class="mt-2 text-white/70 text-sm"><?php echo e($p['subtitle']); ?></p>

                            <div class="mt-4 flex flex-wrap gap-1">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $p['stack']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span
                                        class="text-xs rounded-full bg-white/5 border border-white/10 px-2.5 py-1 text-white/85">
                                        <?php echo e($tag); ?>

                                    </span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>

                            <p class="mt-4 text-xs text-white/55">
                                Status: <?php echo e($p['status']); ?>

                            </p>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </section>


        <!-- WHY CHOOSE ME -->
        <section class="mx-auto max-w-6xl px-4 py-12">
            <div class="mb-8">
                <h2 class="text-2xl md:text-3xl font-bold text-white">Why Choose Me</h2>
                <p class="mt-2 text-white/70 max-w-2xl">
                    I focus on clean code, security, performance, and clear communication.
                </p>
            </div>

            <div class="grid md:grid-cols-3 gap-6">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = [['🔒', 'Secure & Reliable', 'Validation, auth, permissions, and best practices.'], ['⚡', 'Fast Performance', 'Optimized queries, caching, and clean architecture.'], ['🤝', 'Clear Communication', 'Regular updates, clean documentation, on-time delivery.']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="rounded-md p-6 glass-soft cyber-glow">
                        <div class="text-3xl mb-3"><?php echo e($w[0]); ?></div>
                        <h3 class="text-white font-semibold text-lg"><?php echo e($w[1]); ?></h3>
                        <p class="mt-2 text-white/70 text-sm"><?php echo e($w[2]); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </section>


        <!-- PROCESS -->
        <section class="mx-auto max-w-6xl px-4 py-12">
            <div class="mb-8">
                <h2 class="text-2xl md:text-3xl font-bold text-white">How I Work</h2>
                <p class="mt-2 text-white/70 max-w-2xl">
                    A smooth workflow to deliver quality products—on time.
                </p>
            </div>

            <div class="grid md:grid-cols-5 gap-4">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = [['1', 'Requirements', 'Understand goals, features, and timeline.'], ['2', 'Planning', 'Database + architecture + UI plan.'], ['3', 'Development', 'Laravel/WordPress development with best practices.'], ['4', 'Testing (SQA)', 'Manual testing, bug fix, regression checks.'], ['5', 'Deploy & Support', 'Deploy + post-launch support and maintenance.']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="rounded-md p-5 glass-soft cyber-glow">
                        <div
                            class="w-10 h-10 rounded-md bg-emerald-400/15 border border-emerald-400/20 flex items-center justify-center font-bold text-emerald-200">
                            <?php echo e($step[0]); ?>

                        </div>
                        <h3 class="mt-3 font-semibold text-white"><?php echo e($step[1]); ?></h3>
                        <p class="mt-2 text-sm text-white/70"><?php echo e($step[2]); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </section>


        <!-- TECH STACK -->
        <section class="mx-auto max-w-6xl px-4 py-12">
            <div class="mb-8">
                <h2 class="text-2xl md:text-3xl font-bold text-white">Tech Stack</h2>
                <p class="mt-2 text-white/70 max-w-2xl">
                    Tools and technologies I use to build scalable and maintainable applications.
                </p>
            </div>

            <div class="grid md:grid-cols-4 gap-6">
                <div class="rounded-md p-6 glass-soft cyber-glow">
                    <h3 class="text-white font-semibold">Backend</h3>
                    <div class="mt-4 flex flex-wrap gap-2 text-sm">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = ['Laravel', 'PHP', 'CodeIgniter', 'MySQL', 'Redis', 'Queues', 'Sanctum']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span
                                class="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-white/85"><?php echo e($t); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>

                <div class="rounded-md p-6 glass-soft cyber-glow">
                    <h3 class="text-white font-semibold">Frontend</h3>
                    <div class="mt-4 flex flex-wrap gap-2 text-sm">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = ['Blade', 'React', 'Tailwind CSS', 'Alpine.js', 'JavaScript', 'Bootstrap']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span
                                class="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-white/85"><?php echo e($t); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>

                <div class="rounded-md p-6 glass-soft cyber-glow">
                    <h3 class="text-white font-semibold">WordPress</h3>
                    <div class="mt-4 flex flex-wrap gap-2 text-sm">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = ['Theme Development', 'Customization', 'Elementor', 'SEO Basics', 'Speed Optimization']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span
                                class="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-white/85"><?php echo e($t); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>

                <div class="rounded-md p-6 glass-soft cyber-glow">
                    <h3 class="text-white font-semibold">Tools</h3>
                    <div class="mt-4 flex flex-wrap gap-2 text-sm">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = ['Git', 'Postman', 'Linux', 'cPanel', 'VPS', 'Nginx (Basic)']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span
                                class="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-white/85"><?php echo e($t); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>
            </div>
        </section>


        <!-- STATS -->
        <section class="mx-auto max-w-6xl px-4 py-5">
            <div class="grid md:grid-cols-4 gap-6">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = [['20+', 'Projects Completed'], ['3+', 'Years Experience'], ['24h', 'Response Time'], ['100%', 'Quality Focus']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="rounded-md p-6 text-center glass-soft cyber-glow">
                        <div class="text-3xl font-extrabold text-white"><?php echo e($s[0]); ?></div>
                        <div class="mt-2 text-sm text-white/70"><?php echo e($s[1]); ?></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </section>


        <!-- CTA -->
        <section class="mx-auto max-w-6xl px-4 py-10">
            <div
                class="rounded-md glass cyber-glow p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                <div>
                    <h3 class="text-xl font-bold text-white">Need a reliable developer for your project?</h3>
                    <p class="text-white/70 mt-2">
                        Let’s discuss your requirements and build something great.
                    </p>
                </div>

                <a href="<?php echo e(route('contact')); ?>"
                    class="rounded-md bg-emerald-400/20 border border-emerald-400/30 px-6 py-3 font-semibold text-emerald-100 hover:bg-emerald-400/25 transition cyber-glow">
                    Let’s Talk
                </a>
            </div>
        </section>


        <!-- TESTIMONIALS -->
        <section class="mx-auto max-w-6xl px-4 py-12">
            <div class="mb-8">
                <h2 class="text-2xl md:text-3xl font-bold text-white">Testimonials</h2>
                <p class="mt-2 text-white/70 max-w-2xl">What clients say about working with me.</p>
            </div>

            <?php
                $testimonials = [
                    [
                        'text' => 'Excellent work, delivered on time and very professional communication.',
                        'name' => 'Client Name',
                        'role' => 'Business Owner',
                    ],
                    [
                        'text' => 'Very skilled Laravel developer. Clean code and fast delivery.',
                        'name' => 'Client Name',
                        'role' => 'Project Manager',
                    ],
                    [
                        'text' => 'Great experience—quick responses and solid backend skills.',
                        'name' => 'Client Name',
                        'role' => 'Startup Founder',
                    ],
                    [
                        'text' => 'Reliable, communicative, and security-focused developer.',
                        'name' => 'Client Name',
                        'role' => 'CTO',
                    ],
                ];

                // divide testimonials into groups of 2
                $groups = array_chunk($testimonials, 2);
            ?>

            <div x-data="{
                active: 0,
                total: <?php echo e(count($groups)); ?>,
                next() { this.active = (this.active + 1) % this.total },
                prev() { this.active = (this.active - 1 + this.total) % this.total }
            }" x-init="setInterval(() => next(), 6000)" class="relative">
                <!-- SLIDES -->
                <div class="overflow-hidden">
                    <div class="flex transition-transform duration-500"
                        :style="`transform: translateX(-${active * 100}%);`">

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="min-w-full grid md:grid-cols-2 gap-6">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="rounded-md p-6 glass-soft cyber-glow">
                                        <p class="text-white/85">“<?php echo e($t['text']); ?>”</p>
                                        <p class="mt-3 text-sm text-white/55">
                                            — <?php echo e($t['name']); ?>, <?php echo e($t['role']); ?>

                                        </p>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    </div>
                </div>

                <!-- CONTROLS -->
                <div class="mt-6 flex items-center justify-between">
                    <button @click="prev()"
                        class="rounded-md border border-white/10 bg-white/5 px-4 py-2 text-white hover:border-emerald-400/30 transition">
                        ← Prev
                    </button>

                    <!-- DOTS -->
                    <div class="flex gap-2">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php for($i = 0; $i < count($groups); $i++): ?>
                            <button @click="active=<?php echo e($i); ?>"
                                class="h-2.5 w-2.5 rounded-full border border-emerald-400/30"
                                :class="active === <?php echo e($i); ?> ? 'bg-emerald-400/70' : 'bg-white/10'">
                            </button>
                        <?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <button @click="next()"
                        class="rounded-md border border-white/10 bg-white/5 px-4 py-2 text-white hover:border-emerald-400/30 transition">
                        Next →
                    </button>
                </div>
            </div>
        </section>


        <!-- FAQ -->
        <section class="mx-auto max-w-6xl px-4 py-12">
            <div class="mb-8">
                <h2 class="text-2xl md:text-3xl font-bold text-white">FAQ</h2>
                <p class="mt-2 text-white/70 max-w-2xl">
                    Answers to common questions clients ask before starting.
                </p>
            </div>

            <?php
                $faqs = [
                    [
                        'q' => 'How much does a project cost?',
                        'a' =>
                            'It depends on features and complexity. Share your requirements and I will provide a clear quote.',
                    ],
                    [
                        'q' => 'How long will it take?',
                        'a' => 'Small sites take a few days, larger systems take 2–6 weeks depending on scope.',
                    ],
                    [
                        'q' => 'Do you provide support after delivery?',
                        'a' => 'Yes. I provide post-launch support and maintenance options.',
                    ],
                    [
                        'q' => 'Do you work with WordPress too?',
                        'a' => 'Yes. Theme development, customization, speed optimization, and business websites.',
                    ],
                    [
                        'q' => 'Can you build APIs for mobile apps?',
                        'a' => 'Yes. I build secure REST APIs with authentication and documentation.',
                    ],
                    [
                        'q' => 'Do you ensure security?',
                        'a' => 'Yes. Validation, authorization, and best practices are applied in every project.',
                    ],
                    [
                        'q' => 'Can you build APIs for mobile apps?',
                        'a' => 'Yes. I build secure REST APIs with authentication, versioning, and documentation.',
                    ],
                    [
                        'q' => 'Do you ensure security?',
                        'a' =>
                            'Yes. Validation, authorization, rate limiting, and best practices are applied in every project.',
                    ],
                ];

                // FAQ ভাগ করা
                $leftFaqs = array_filter($faqs, fn($v, $k) => $k % 2 === 0, ARRAY_FILTER_USE_BOTH);
                $rightFaqs = array_filter($faqs, fn($v, $k) => $k % 2 === 1, ARRAY_FILTER_USE_BOTH);
            ?>

            <div class="grid md:grid-cols-2 gap-6 items-start">

                <!-- LEFT COLUMN -->
                <div class="space-y-6">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $leftFaqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div x-data="{ open: false }" class="rounded-md p-6 glass-soft cyber-glow h-fit">

                            <button @click="open = !open" class="w-full flex items-start justify-between gap-4 text-left">
                                <h3 class="text-white font-semibold"><?php echo e($faq['q']); ?></h3>
                                <span class="text-white/60 text-xl" x-text="open ? '−' : '+'"></span>
                            </button>

                            <div x-show="open" x-transition class="mt-3 text-sm text-white/70 leading-relaxed">
                                <?php echo e($faq['a']); ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <!-- RIGHT COLUMN -->
                <div class="space-y-6">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $rightFaqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div x-data="{ open: false }" class="rounded-md p-6 glass-soft cyber-glow h-fit">

                            <button @click="open = !open" class="w-full flex items-start justify-between gap-4 text-left">
                                <h3 class="text-white font-semibold"><?php echo e($faq['q']); ?></h3>
                                <span class="text-white/60 text-xl" x-text="open ? '−' : '+'"></span>
                            </button>

                            <div x-show="open" x-transition class="mt-3 text-sm text-white/70 leading-relaxed">
                                <?php echo e($faq['a']); ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/pages/home.blade.php ENDPATH**/ ?>