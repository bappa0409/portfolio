<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Visitor extends Model
{
    protected $fillable = [
        'ip',
        'name',
        'user_agent',
        'visit_date',
        'visits',
    ];
}